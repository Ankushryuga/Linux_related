#ifndef _SENDER_H_
#define _SENDER_H_
#include<iostream>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<unistd.h>
#include<fstream>
#include<sstream>
#include<sys/stat.h>
#include<string.h>
#include <stdlib.h>
#include <signal.h>
#include<csignal>
#include<limits>
#define MSGBUFSIZE 256
using namespace std;   
class sender1{    
public:
    int sender();
    struct  timeval t_out={0,0};
	 struct sockaddr_in addr;
	char ip[INET_ADDRSTRLEN];
	
    char msgbuf;
       const char *message1 = "--- sender is active ---";
    int i = 0, j = 0, g = 0, k = 0;
    int arr[5];
    int port;

    sender1();    //constructor.
    ~sender1();   //destructor.
};

    
#endif



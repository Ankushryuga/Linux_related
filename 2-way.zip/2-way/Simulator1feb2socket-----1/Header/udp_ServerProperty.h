#ifndef UDP_SERVERPROPERTY_H_
#define UDP_SERVERPROPERTY_H_
#include<iostream>
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<unistd.h>
#include<fstream>
#include<sstream>
#include<sys/stat.h>
#include<string.h>
#include <stdlib.h>
#include <signal.h>
#include<csignal>

#include "udp_exception.h"
using namespace std;


   typedef struct packet{
        char data[2048];
    }Packet;

    typedef struct frame{
        int frame_type;
        int sq_no;
        int ack;
        Packet packet;
    }Frame;

class udp_ServerProperty{
    public:
        struct timeval time_out={0,0}; 
        struct frame_t{
            long int *ID;
            long int *length;
            char* data;
    };

        int serverStatus=1;
        struct sockaddr_storage serverStorage;
        long unsigned int portNumber;                 // for server port number.
        long unsigned int timeDelay;                  // for time delay.
        long unsigned int resendFrameTime;            // for little amount of time.
        long unsigned int resendFrameLongPeriod;      // for little long period of time.
        int *total_Frame=NULL, *resend_Frame=NULL, *drop_Frame=NULL, *time_out_flag=NULL;
        long int i=0;
        int BUFF_SIZE;
      //  char *receive=NULL;
        char *send=NULL;
        char *commandReceive=NULL;
        ssize_t *readMessage=NULL;
        ssize_t *length=NULL;
        off_t *file_size=NULL;
        int *ack_num=NULL;         //recieve frame ack
        int *ack_send=NULL;
        struct sockaddr_in server_addr, client_addr;
        struct sockaddr_in second_server_addr, second_client_addr;
        struct stat *st=NULL;
        int *sendMessage;
        int *receiveMessage;
        socklen_t serverLength;
        int* udpSocket;
       // socklen_t clientlent;
        //struct frame *Frame=new struct;
};
#endif

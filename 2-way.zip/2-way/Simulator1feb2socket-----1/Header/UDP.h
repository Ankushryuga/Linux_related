#ifndef _UDP_H_
#define _UDP_H_


#include "../Header/listener.h"
#include "../Header/sender.h"
#include "../Header/udp_Client.h"
#include "../Header/udp_server.h"

class UDP{
    public:
    void clientserver();
    void UDPConnection(int argc, char *argv[]);

};



#endif
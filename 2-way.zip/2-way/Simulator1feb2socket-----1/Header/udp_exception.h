#ifndef UDP_EXCEPTION_H_
#define UDP_EXCEPTION_H_
#include <string>

class Exception
{
public:
	Exception(std::string s) : m_s(s) {};
	~Exception() {};
	std::string description() { return m_s; }
private:
	std::string m_s;

};


#endif

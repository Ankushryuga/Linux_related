#ifndef _UDP_SERVER_H_
#define _UDP_SERVER_H_
#include "udp_ServerProperty.h"
#include "udp_exception.h"

class udp_unicast:public udp_ServerProperty{
    public:   
        void signal_Handler(int signal);       // it is for clean exiting and freeing the port and others.
        int createSocket();
        void bindSocket(int* udpSocket,int* secondsocket);
        void sendReceiveData(int* udpSocket);
        void sendFrame(int* udpSocket,int* secondsocket, struct sockaddr_in *server_addr, struct sockaddr_in *client_addr, struct sockaddr_in *second_server_addr, struct sockaddr_in *second_client_addr);
        void udpUnicast();
        udp_unicast();
        ~udp_unicast();
};
class UDP_Server{
    public:
        void selectOperation();
        //void Driver();
        void Driver();
};
//void selectOperation();
//void Driver();

#endif
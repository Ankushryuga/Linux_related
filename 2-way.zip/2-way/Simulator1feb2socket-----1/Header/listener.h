#ifndef _LISTENER_H_
#define _LISTENER_H_
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <string.h>
#include <stdio.h>
#include<fstream>
#include<sstream>
#include <stdlib.h>
#include <iostream>
using namespace std;
#define MSGBUFSIZE 256


class listener1{
public:
 int listener(int argc, char *argv[]);
 listener1();
    ~listener1();
};
#endif

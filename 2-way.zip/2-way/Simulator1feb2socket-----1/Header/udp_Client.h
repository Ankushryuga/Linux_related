#ifndef _UDP_CLIENT_H_
#define _UDP_CLIENT_H_
#include "udp_ClientProperty.h"
#include "udp_exception.h"

class udp_ClientUnicast:public udp_ClientProperty{
    public:
        void signal_Handler(int signal);
        int createSocket();
        void sendReceiveData(int* udpClientSocket, int* secondSocket);
        void udpClientUnicast();
        udp_ClientUnicast();
        ~udp_ClientUnicast();
};

class UDP_Client{
    public:
        void selectOperation();
        void Driver(int argc, char *argv[]);
};



//void selectOperation();
//void Driver();

#endif
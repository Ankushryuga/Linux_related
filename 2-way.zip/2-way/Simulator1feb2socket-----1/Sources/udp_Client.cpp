#include "../Header/udp_Client.h"
//#include "../Header/listener.h"
#include "../Header/sender.h"
#include "../Header/listener.h"

//UNICASTINGNGGGGGG
int udp_ClientUnicast::createSocket(){
    udpClientSocket=new int;
    *udpClientSocket=socket(AF_INET, SOCK_DGRAM, 0);
    secondSocket=new int;
    *secondSocket=socket(AF_INET, SOCK_DGRAM, 0);
    if(*secondSocket<0){
        std::cout<<"Second socket failed: "<<std::endl;
        exit(1);
    }
    else{
        std::cout<<"Second Socket created successfully: "<<std::endl;
    }
    if(*udpClientSocket<0){
        std::cout<<"SOCKET CREATION FAILED: "<<std::endl;
    }
    else{
        std::cout<<"Socket created successfully:"<<std::endl;
    }
    std::cout<<"Socket address in createSocket: "<<udpClientSocket<<std::endl;
    sendReceiveData(udpClientSocket, secondSocket);
    return 0;
}
void udp_ClientUnicast::sendReceiveData(int* udpClientSocket, int* secondSocket){
     cout<<"In sendrecer:";
    ifstream files;
    string *line;
    int BUFF_SIZE;
    line =new string;
    IP=new char[INET_ADDRSTRLEN];
    try{
    files.open("../ResourceFiles/config.config");
    while(getline(files, *line)){
        istringstream sin(line->substr(line->find("=")+1));
        if(line->find("port")!=-1){
            sin>>portNumber;
        }else if(line->find("BUFF_SIZE")!=-1){
            sin>>BUFF_SIZE;
        }
        else if(line->find("ipaddress")!=-1){
            sin>>IP;
        }
    }}
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    socklen_t clientAddrLen, serverAddrLen;

    inet_pton(AF_INET, IP, &(client_addr.sin_addr));
    inet_ntop(AF_INET, &(client_addr.sin_addr), IP, INET_ADDRSTRLEN);
   // memset(&client_addr, 0, sizeof(client_addr));
    memset(&server_addr, '\0', sizeof(server_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(portNumber);
    server_addr.sin_addr.s_addr=inet_addr(IP);
    cout<<"BUFF SIZE IS:"<<BUFF_SIZE<<endl;
    char buff[BUFF_SIZE];
    int frame_id=0;
    Frame1 frame_send;
    Frame1 frame_recv;
    int ack_recv=1;
    socklen_t addr_size;
    // struct memory allocation:
 
   while (1){
       cout<<"Enter Data: ";
            scanf("%s", buff);
        if(ack_recv==1){
            frame_send.sq_no=frame_id;
            frame_send.frame_type=1;
            frame_send.ack=0;            
            strcpy(frame_send.packet1.data, buff);
            sendto(*udpClientSocket, &frame_send, sizeof(Frame1), 0, (struct sockaddr*)&server_addr, sizeof(server_addr));
            cout<<"->Frame send\n";
        }
       addr_size=sizeof(server_addr);
        int f_recv_size=recvfrom(*udpClientSocket, &frame_recv, sizeof(frame_recv), 0, (struct sockaddr*)&server_addr, &addr_size);

        if(f_recv_size>0 && frame_recv.sq_no==0 && frame_recv.ack==frame_id+1){
            cout<<"->Ack Received: "<<endl;
            ack_recv=1;
        }
        else{
            cout<<"->Ack Not Received: "<<endl;
            ack_recv=0;
        }
        frame_id++;
    }
    close(*udpClientSocket);
}


// UNICASTINGNGGGGG
void udp_ClientUnicast::udpClientUnicast(){
    udp_ClientUnicast::createSocket();
}
udp_ClientUnicast::udp_ClientUnicast(){}
udp_ClientUnicast::~udp_ClientUnicast(){}

/*
void selectOperation(){
    std::cout<<"\t\t 1. CLIENT_UNICAST: "<<std::endl;
    std::cout<<"\t\t 2. CLIENT MULTICAST: "<<std::endl;
    std::cout<<"\t\t 3. CLIENT BROADCAST: "<<std::endl;
}

void Driver(){
    int choice;
     udp_ClientUnicast clientUnicast;
     udp_ClientMulticast clientMulticast;
     udp_ClientBroadCast clientBroadcast;
    do{
        selectOperation();
        std::cin>>choice;
        std::cout<<std::endl;
        switch (choice)
        {   
        case 1:
            std::cout<<"\t\t  CLEINT UNICAST: "<<std::endl;
            clientUnicast.udpClientUnicast();
            clientUnicast.~udp_ClientUnicast();
            break;
        case 2:
            std::cout<<"\t\t  CLIENT MULTICAST: "<<std::endl;
            clientMulticast.udpClientMulticast();
            clientMulticast.~udp_ClientMulticast();;
            break;
        case 3:
            std::cout<<"\t\t  CLIENT BROADCASR: "<<std::endl;
            clientBroadcast.udpClientBroadCast();
            clientBroadcast.~udp_ClientBroadCast();
        case 4:
            std::cout<<"\t\t GET OUT: "<<std::endl;
            exit(1);
        default:
            std::cout<<"\t\t WRONG CHOICE: "<<std::endl;
            exit(1);
            break;
        }
    }while ((choice!='0'));
}
*/

void UDP_Client::selectOperation(){
    std::cout<<"\t\t 1. CLIENT_UNICAST: "<<std::endl;
    std::cout<<"\t\t 2. CLIENT MULTICAST: "<<std::endl;
    //std::cout<<"\t\t 3. CLIENT BROADCAST: "<<std::endl;
}


void UDP_Client::Driver(int argc, char *argv[]){
    int choice;
     udp_ClientUnicast clientUnicast;
     sender1 send;
     listener1 listobj;
     
    do{
        selectOperation();
        std::cin>>choice;
        std::cout<<std::endl;
        switch (choice)
        {   
        case 1:
            std::cout<<"\t\t  CLEINT UNICAST: "<<std::endl;
            clientUnicast.udpClientUnicast();
            clientUnicast.~udp_ClientUnicast();
            break;
        case 2:
            std::cout<<"\t\t  CLIENT MULTICAST: "<<std::endl;
            listobj.listener(argc, argv);
            //send.~sender1();
            listobj.~listener1();
            break;
        case 4:
            std::cout<<"\t\t GET OUT: "<<std::endl;
            exit(1);
            break;
        default:
            std::cout<<"\t\t WRONG CHOICE: "<<std::endl;
            exit(1);
            break;
        }
    }while ((choice!='0'));
}



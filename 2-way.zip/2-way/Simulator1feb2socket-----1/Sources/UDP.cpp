#include "../Header/UDP.h"
/*
void UDP::clientserver(){
    cout<<"\t 1.Client: "<<endl;
    cout<<"\t 2.Server: "<<endl;
}
*/
/*
void UDP::UDPConnection(int argc, char *argv[]){
    int choice;
    int connection;
    UDP_Client client;
    UDP_Server server;
    do{
       // clientserver();
        cin>>choice;
        cout<<endl;
        switch(choice){
            case 1:
                cout<<"\t Client Panel: "<<endl;
                client.Driver(argc, argv);
            //    Driver();
                break;
            case 2:
                cout<<"\t Server Panel: "<<endl;
                server.Driver();
                break;
            default:
                cout<<"\t Wrong choice:"<<endl;
                exit(1);
                break;
        }
    }while(choice!=0);
}
//UDP();
//~UDP();
*/

void UDP::UDPConnection(int argc, char** argv){
    string line;
    ifstream fileName;
    int unicastPort;
    int MulticastPort;
    udp_ClientUnicast clientUnicast;
    udp_unicast udpserver;
    sender1 udpserverMulticast;
    listener1 udpclientMulticast;
    try{
        fileName.open("../ResourceFiles/config.config");
        while(getline(fileName, line)){
            istringstream sin(line.substr(line.find("=")+1));
            if(line.find("unicastport")!=-1){
                sin>>unicastPort;
            }
        }
    }catch(std::exception ex){
        cerr<<"Sorry file not found: "<<endl;
    }

    ifstream fnk;
    try{
        fnk.open("../ResourceFiles/con.cfg");
        while(getline(fnk, line)){
            istringstream sin(line.substr(line.find("=")+1));
            if(line.find("port")!=-1){
                sin>>MulticastPort;
            }
        }
    }catch(std::exception ex){
        cerr<<"Sorry file not found: "<<endl;
    }

        if(argc==1){
            cout<<"Please Enter like ./program_name 1(client) 2(server)"<<endl;
        }
        int type;
        if(argc<=2){
            type=atoi(argv[1]);
        }
        else{
            cout<<"Sorry commands verification faile:: "<<endl;
            exit(1);
        }
         int port;
         int serverport;
        if(type==1){
            cout<<"You are Now Listner (Client) "<<endl;
            cout<<"Unicast Working on 3500 Port: "<<endl;
            cout<<"Multicast Working on 4500 Port:"<<endl;
            cout<<"Please Enter any 1 port number from above two for communication: "<<endl;
            cin>>port;
            while (1)
            {
                if(cin.fail()){
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(),'\n');
                    cout<<"Please Enter proper port: "<<endl;
                    cin>>port;
                }
                if(!cin.fail())
                break;
            }
            cout<<"Enter Port number is: "<<port<<endl;
            if(port==unicastPort){
                cout<<"You are in UDP unicast: "<<endl;
                clientUnicast.udpClientUnicast();
                clientUnicast.~udp_ClientUnicast();
            }
            else if(port==MulticastPort){
                cout<<"You are in UDP Multicast: "<<endl;
                udpclientMulticast.listener(argc, argv);
                udpclientMulticast.~listener1();
                
            }
            else{
                cout<<"sorry wrong input: "<<endl;
                exit(1);
            }
            
        }
       
        else if(type==2){
            cout<<"You are Now Listner (Server)"<<endl;
          //  cout<<"You are Now Listner (Client) "<<endl;
            cout<<"Unicast Working on 3500 Port: "<<endl;
            cout<<"Multicast Working on 4500 Port:"<<endl;
            cout<<"Please Enter any 1 port number from above two for communication: "<<endl;
            cin>>serverport;
            while (1)
            {
                if(cin.fail()){
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(),'\n');
                    cout<<"Please Enter proper port: "<<endl;
                    cin>>serverport;
                }
                if(!cin.fail())
                break;
            }
            cout<<"Enter Port number is: "<<serverport<<endl;
            if(serverport==unicastPort){
                cout<<"You are in UDP unicast Server: "<<endl;
                udpserver.udpUnicast();
                udpserver.~udp_unicast();
            }
            else if(serverport==MulticastPort){
                cout<<"You are in UDP Multicast Server: "<<endl;
                udpserverMulticast.sender();
                udpserverMulticast.~sender1();
            }
            else{
                cout<<"sorry wrong input: "<<endl;
                exit(1);
            }
        }
        else{
            cout<<"sorry wrong input: "<<endl;
        }
}
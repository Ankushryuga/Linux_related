#include "../Header/udp_server.h"
#include "../Header/listener.h"
#include "../Header/sender.h"

// for releasing port number. if client or server unexpectedly closes application.
void udp_unicast::signal_Handler(int signal){
    if(signal==SIGINT){
        cout<<"====> EXITING <===="<<signal;
      //  close(*udpSocket);
    }
    exit(1);
}

void udp_unicast::sendFrame(int* udpSocket, int* secondsocket, struct sockaddr_in *server, struct sockaddr_in *client, struct sockaddr_in *second_server_addr, struct sockaddr_in *second_client_addr){
    int frame_id=0;
    Frame frame_recv;
    Frame frame_send;
    char *buff;
    ifstream files;
    string line;
    int *BUFF_SIZE;
    BUFF_SIZE=new int;
    int *status;
    status=new int;
    *status=1;
    try{
        files.open("../ResourceFiles/config.config");
        while(getline(files, line)){
            istringstream sin(line.substr(line.find("=")+1));
            if(line.find("BUFF_SIZE")!=-1){
                sin>>*BUFF_SIZE;
            }}}
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    cout<<"BUFF size is: "<<*BUFF_SIZE<<endl;
    buff=new char[*BUFF_SIZE];
    socklen_t addr_size;
    addr_size=sizeof(*client);
    socklen_t seccond_addr_size;
    seccond_addr_size=sizeof(*second_client_addr);
    while(1){
        cout<<"Server is receiving: "<<endl;

        int f_recv_size=recvfrom(*udpSocket, &frame_recv, sizeof(Frame),0, (struct sockaddr*)client, &addr_size);
        if(f_recv_size>0 && frame_recv.frame_type==1 && frame_recv.sq_no==frame_id){
            cout<<"Frame Coming from IP & PORT NUMBER: "<<inet_ntoa(client->sin_addr)<<" "<<(int)htons(client->sin_port)<<" --->Frame id is: "<<frame_id<<"-->Frame Received: "<<frame_recv.packet.data<<endl;
            frame_send.sq_no=0; 
            frame_send.frame_type=0;
            frame_send.ack=frame_recv.sq_no+1;
             sendto(*udpSocket, &frame_send, sizeof(frame_send),0,(struct sockaddr* )client, addr_size);
            cout<<"ACK send\n";
        }
        else{
            cout<<"->Frame not received: "<<endl;
        }
        frame_id++;
    }
}

void udp_unicast::sendReceiveData(int *udpSocket){}

//creating socket.
int udp_unicast::createSocket(){
    udpSocket=new int;
    int* secondSocket;
    secondSocket=new int;
    *udpSocket=socket(AF_INET, SOCK_DGRAM,IPPROTO_UDP);
    *secondSocket=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(*secondSocket<0){
        cout<<"\t sorry second socket not working: "<<endl;
        exit(1);
    }
    else{
        cout<<"\t Second socket created successfully: "<<endl;
    }
    if(*udpSocket<0){
        cout<<"\tSorry socket creation failed: "<<endl;
        exit(1);
    }else
        cout<<"\tsocket created successfully: "<<endl;
        
     u_int yes = 1;
    if (
        setsockopt(
            *udpSocket, SOL_SOCKET, SO_REUSEADDR, (char*) &yes, sizeof(yes)
        ) < 0
    ){
       perror("Reusing ADDR failed");
       return 1;
    }    
        bindSocket(udpSocket, secondSocket);
    return 0;    
}
void udp_unicast::bindSocket(int* udpSocket, int* secondsocket){
    cout<<"socket in before calling BInd function is: "<<"value is: "<<*udpSocket<<"address is: "<<udpSocket<<endl;
   // createSocket(udpSocket);
    cout<<"socket in after calling cresocket function is: "<<"value is: "<<*udpSocket<<"address is: "<<udpSocket<<endl;
    ifstream files;
    string line;
    int secondport;
   // cout<<"socket address in bind is: "<<udpSocket<<endl;
    try
    {
        files.open("../ResourceFiles/config.config");
        while (getline(files, line))
        {
            istringstream sin(line.substr(line.find("=")+1));
            if(line.find("port")!=-1){
                sin>>portNumber;
            }else if(line.find("secondport")!=-1){
                sin>>secondport;
            }
        }   
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    memset(&server_addr,'\0', sizeof(server_addr));
    memset(&second_server_addr,'\0', sizeof(second_server_addr));
    memset(&client_addr,'\0',sizeof(client_addr));
    memset(&second_client_addr,'\0', sizeof(second_client_addr));

    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(portNumber);
    server_addr.sin_addr.s_addr=INADDR_ANY;

    // for second socket
    second_server_addr.sin_family=AF_INET;
    second_server_addr.sin_port=htons(secondport);
    second_server_addr.sin_addr.s_addr=INADDR_ANY;
    
    if(bind(*udpSocket, (struct sockaddr*)&server_addr, sizeof(server_addr))<0){
        cerr<<"\t Error while binding: "<<endl;
        close(*udpSocket);
        exit(-1);
    }
    else{
        cout<<"\t Server Binded successfully: "<<endl;
    }
    if(bind(*secondsocket, (struct sockaddr*)&second_server_addr, sizeof(second_server_addr))<0){
        cerr<<"\t Error while binding second socket: "<<endl;
        close(*secondsocket);
        exit(-1);
    }
   sendFrame(udpSocket, secondsocket, &server_addr, &client_addr, &second_server_addr, &second_client_addr);
}
// Unicasting
udp_unicast::udp_unicast(){}   
udp_unicast::~udp_unicast(){}
void udp_unicast::udpUnicast(){

    udp_unicast::createSocket();
}



/*
void selectOperation(){
    cout<<"\t1. UDP UNICAST"<<endl;
    cout<<"\t2. UDP MULTICAST"<<endl;
    cout<<"\t3. UDP BROADCAST"<<endl;
    cout<<"\t0. Get out"<<endl;
}
void Driver(){
    int input;
    udp_unicast unicast;            // object of udp_unicast class
    udp_Multicast multicast;        // object of udp_Multicast class
    udp_Broadcast broadcast;        // object of udp_Broadcast class
    do{
    selectOperation();
    cin>>input;
    switch(input){
        case 1:
            cout<<"\t\t    UDP---UNICAST "<<endl;
            unicast.udpUnicast();
            unicast.~udp_unicast();
            break;
        case 2:
            cout<<"\t\t     UDP---MULTICASTING "<<endl;
            multicast.udpMulticast();
            multicast.~udp_Multicast();
            break;
        case 3:
            cout<<"\t\t     UDP---BROADCASTING "<<endl;
            broadcast.udpBroadcast();
            broadcast.~udp_Broadcast();
            break;
        case 0:
            cout<<"\t\t     APPLICATION CLOSED "<<endl;
            exit(1);
            break;
        default:
            cout<<"Wrong choice: "<<endl;
            break;
    }}
    while(input!=0);   
}
*/

void UDP_Server::selectOperation(){
    cout<<"\t1. UDP UNICAST"<<endl;
    cout<<"\t2. UDP MULTICAST"<<endl;
  //  cout<<"\t3. UDP BROADCAST"<<endl;
    cout<<"\t0. Get out"<<endl;
}
void UDP_Server::Driver(){
    int input;
    udp_unicast unicast;            // object of udp_unicast class
    listener1 listen;
    sender1 sendobj;
    do{
    selectOperation();
    cin>>input;
    switch(input){
        
        case 1:
            cout<<"\t\t    UDP---UNICAST "<<endl;
            unicast.udpUnicast();
            unicast.~udp_unicast();
            break;
        case 2:
            cout<<"\t\t     UDP---MULTICASTING "<<endl;
        //    listen.listener(argc, argv); // edited on 30 jan
            sendobj.sender();
            sendobj.~sender1();
            break;
        case 0:
            cout<<"\t\t     APPLICATION CLOSED "<<endl;
            exit(1);
            break;
        default:
            cout<<"Wrong choice: "<<endl;
            break;
    }}
    while(input!=0); 
}
#include "../Header/listener.h"
listener1::listener1(){}

 

int listener1:: listener(int argc, char *argv[]){
    char group[INET_ADDRSTRLEN];
    
    ifstream fileName;
    string line;
    int port;
    try{
        fileName.open("../ResourceFiles/con.cfg");
        while(getline(fileName, line)){
        istringstream sin(line.substr(line.find("=")+1));
        if(line.find("IP")!=-1){
            sin>>group;
        }
        if(line.find("port")!=-1){
            sin>>port;
        }
        }
    }catch(std::exception str){
        cerr<<"File Not found exception : "<<endl;
    }


    struct sockaddr_in addr;
    inet_pton(AF_INET, group, &(addr.sin_addr));

    inet_ntop(AF_INET, &(addr.sin_addr), group, INET_ADDRSTRLEN);

 //   edited here by ankush
    /*if (argc >= 2) {
       printf("Command line args should be multicast group and port\n");
       printf("(e.g. for SSDP, `listener 239.255.255.250 1900`)\n");
       return 1;
    }
    */
// original 
//    char* group = argv[1]; // e.g. 239.255.255.250 for SSDP
//    int port = atoi(argv[2]); // 0 if error, which is an invalid port


// Edited here by ankush on 1 feb
    
 

 


    // create what looks like an ordinary UDP socket
    //
   /* if (argc >= 4) {
       printf("Command line args should be multicast group and port\n");
       printf("(e.g. for SSDP, `listener 239.255.255.250 1902)\n");

       return 1;
    }
    */

  //  char* group=argv[2];
   // int port=atoi(argv[3]);

    // create what looks like an ordinary UDP socket
    //
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) {
        perror("socket");
        return 1;
    }

    // allow multiple sockets to use the same PORT number

    u_int yes = 1;
    if (
        setsockopt(
            fd, SOL_SOCKET, SO_REUSEADDR, (char*) &yes, sizeof(yes)
        ) < 0
    ){
       perror("Reusing ADDR failed");
       return 1;
    }

        // set up destination address
    //
    //struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY); // differs from sender
    addr.sin_port = htons(port);

    // bind to receive address
    //
    if (bind(fd, (struct sockaddr*) &addr, sizeof(addr)) < 0) {
        perror("bind");
        return 1;
    }

    // use setsockopt() to request that the kernel join a multicast group
    //
    struct ip_mreq mreq;
    mreq.imr_multiaddr.s_addr = inet_addr(group);
    mreq.imr_interface.s_addr = htonl(INADDR_ANY);
    if (
        setsockopt(
            fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*) &mreq, sizeof(mreq)
        ) < 0
    ){
        perror("setsockopt");
        return 1;
    }

    // now just enter a read-print loop
    //
    const char *message = "Hello";
    while (1) {
        char msgbuf[MSGBUFSIZE];
        int addrlen = sizeof(addr);
        int nbytes = recvfrom(fd,msgbuf,MSGBUFSIZE,0,(struct sockaddr *) &addr,(socklen_t*)&addrlen);
       

        if (nbytes < 0) {
            perror("recvfrom");
            return 1;
        }
          int fd1 = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd1 < 0) {
        perror("socket");
        return 1;
            }
               u_int yes1 = 1;
    if (
        setsockopt(
            fd1, SOL_SOCKET, SO_REUSEADDR, (char*) &yes1, sizeof(yes1)
        ) < 0
    ){
       perror("Reusing ADDR failed");
       return 1;
    }
    struct sockaddr_in addr1;
    memset(&addr1, 0, sizeof(addr1));
    addr1.sin_family = AF_INET;
    addr1.sin_addr.s_addr = htonl(INADDR_ANY); // differs from sender
    addr1.sin_port = htons(port);
       
        fd1=fd;
           addr1=addr;
      int Mbytes = sendto(fd1, message, strlen(message), 0, (struct sockaddr *)&addr1, sizeof(addr1));
      if(Mbytes<0)
      return 1;
        msgbuf[nbytes] = '\0';
        puts(msgbuf);

     
}


    return 0;
}
listener1::~listener1(){}

#include "../Header/udp_ServerProperty.h"
#include "../Header/udp_server.h"
#include "../Header/udp_ClientProperty.h"
#include "../Header/udp_Client.h"
#include "../Header/listener.h"
#include "../Header/sender.h"
#include "../Header/UDP.h"

//#include "UDP.cpp"
//#include "Mcl.cpp"
//#include "Mcs.cpp"
//#include "udp_Client.cpp"
//#include "udp_Server.cpp"
int main(int argc, char *argv[]){
    UDP *obj=new UDP;
    obj->UDPConnection(argc, argv);
    obj->~UDP();


   // UDPConnection();
    return 0;
}
#include "../Header/sender.h"
#include<vector>

sender1::sender1() {}
int sender1::sender()
{
 
      //const char *message1 = "--- sender is active ---";
    int i = 0, j = 0, g = 0, k = 0;
    int port;

    ifstream files;
    string line;
    files.open("../ResourceFiles/con.cfg");
    while (getline(files, line))
    {
        istringstream sin(line.substr(line.find("=") + 1));
        if (line.find("port") != -1)
        {
            sin >> port;
        }
        else if (line.find("IP") != -1)
        {
            sin >> ip;
        }
    }

    inet_pton(AF_INET, ip, &(addr.sin_addr));

    inet_ntop(AF_INET, &(addr.sin_addr), ip, INET_ADDRSTRLEN);
    loop :
    cout <<"Enter Port And Message";
   
     while (!(cin >> j)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Enter a number: ";
    }
  
       port=j;
        
        
         char message[MSGBUFSIZE];
         cin>>message;
        // return 0;

        // !!! If test requires, make these configurable via args
        //

        // const int delay_secs = 1;

        // create what looks like an ordinary UDP socket
        //
        int fd = socket(AF_INET, SOCK_DGRAM, 0);
        if (fd < 0)
        {
            perror("socket");
            return 1;
        }

        // set up destination address
        //

        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        // addr.sin_addr.s_addr = inet_addr(group);
        // addr.sin_addr.s_addr=inet_ntoa(ip);
        addr.sin_addr.s_addr = inet_addr(ip);
       
        addr.sin_port = htons(port);

        // std::cout<<"IP addrs">>ip<<std::endl;
        //  now just sendto() our destination!
        //
        char *arr1[10];
        vector<string> vClientIPs;
        int p[10];
        char msgbuf[MSGBUFSIZE];
        int addrlen = sizeof(addr);
        int nbytes = sendto(fd, message, strlen(message), 0, (struct sockaddr *)&addr, sizeof(addr));
        
        int fd1 = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd1 < 0) {
        perror("socket");
        return 1;
            }
               u_int yes1 = 1;
    if (
        setsockopt(
            fd1, SOL_SOCKET, SO_REUSEADDR, (char*) &yes1, sizeof(yes1)
        ) < 0
    ){
       perror("Reusing ADDR failed");
       return 1;
    }
    struct sockaddr_in addr1;
    memset(&addr1, 0, sizeof(addr1));
    addr1.sin_family = AF_INET;
    addr1.sin_addr.s_addr = htonl(INADDR_ANY); // differs from sender
    addr1.sin_port = htons(port);
       
      fd1=fd;
           addr1=addr;
    int addrlen1 = sizeof(addr1);
        int l = 0;
       while (1)
        {
            
            t_out.tv_sec = 1;

            setsockopt(fd1, SOL_SOCKET, SO_RCVTIMEO, (char *)&t_out, sizeof(struct timeval)); // Enable the timeout option if client does not respond

            int mbytes = recvfrom(fd1, msgbuf, MSGBUFSIZE, 0, (struct sockaddr *)&addr1, (socklen_t *)&addrlen1);
            t_out.tv_sec = 4;
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&t_out, sizeof(struct timeval)); // Disable the timeout option
             arr1[i]= inet_ntoa(addr1.sin_addr);
             //vClientIPs.push_back(string(inet_ntoa(addr1.sin_addr)));
             p[i] = ntohs(addr1.sin_port);
            
            //addr1.sin_addr.s_addr = 0;
            //addr1.sin_port = 0;
            
              if (mbytes < 0) {
           // perror("recvfrom");
            goto loop;
                             }
        l++;
            printf("%d ", l);
        printf("%s::>>%d\n",arr1[i], p[i]);
       }
       
   /*  for(int z=0;z<vClientIPs.size();z++)
    {
        cout<<vClientIPs[z];
        cout<<"::>>"<<p[z]<<"\n";
    } 
        msgbuf[nbytes];
        // puts(msgbuf);
       // printf("%s\n", message1);
        
  */
        if (nbytes < g)
        {
            perror("--- sender deactivated ---"); // send to
            return 1;
        }

        // sleep(delay_secs * 0); // Unix sleep is seconds
    }
    
sender1::~sender1()
{
}
